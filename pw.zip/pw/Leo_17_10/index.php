<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title>Projeto - Léo e Rogerio</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/> 
	<link rel="stylesheet" type="text/css" href="css/estilo.css"/>
	<link rel="stylesheet icon" href=""/>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
    
<body>
<div class="row">
<div class="col">
<label class="form-label">Cargo</label>
<select class="form-select" aria-label="Default select example">
  <option selected placeholder="0"</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>
</div>
<div class="col">
<label for="exampleInputEmail1" class="form-label">Area</label>
<select class="form-select" aria-label="Default select example">
<option selected placeholder="0"</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>   
</div>
<br><br>
<br><br>
<button type="submit" class="btn btn-primary">Buscar</button>
</div>
<br>
<div class="row">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Registro</th>
      <th scope="col">Nome</th>
      <th scope="col">Cargo</th>
      <th scope="col">Área</th>
      <th scope="col">Salário</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>

    </tr>
    <tr>
 
    </tr>
    <tr>

    </tr>
  </tbody>
</table>
</div>

</body>
</html>
<style>

body{
  flex-direction:column;
}
</style>